public interface Filter.java {
    boolean accept(Object x);
}

public class Main implements Filter {
    public boolean accept(Object x) {
        return ((String)x).length() < 5;
    }
}

public class BigRectangleFilter implements Filter {
    public boolean accept(Object x) {
        Rectangle rect = (Rectangle)x;
        return 2 * (rect.getWidth() + rect.getHeight()) > 10;
    }
}

public class Main {
    public static ArrayList<Object> collectAll(Filter f, Object[] objects) {
        ArrayList<Object> result = new ArrayList<Object>();
        for (Object obj : objects) {

            if (f.accept(obj)) {
                result.add(obj);
            }
        }
        return result;
    }

    public static void main(String[] args) {


        String[] words = {"luke", "hebenstreit", "school", "class"};
        ShortWordFilter shortWordFilter = new ShortWordFilter();


        ArrayList<Object> shortWords = collectAll(shortWordFilter, words);


        System.out.println("Short words: " + shortWords);

        Rectangle[] rectangles = {new Rectangle(2, 3), new Rectangle(5, 5), new Rectangle(7, 8), new Rectangle(10, 2)};


        BigRectangleFilter bigRectangleFilter = new BigRectangleFilter();

        ArrayList<Object> bigRectangles = collectAll(bigRectangleFilter, rectangles);

        System.out.println("Big rectangles: " + bigRectangles);
    }
}